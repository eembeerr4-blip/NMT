import { expect, it, vi } from "vitest";

vi.mock("server-only", () => ({}));

const fetchMock = vi.fn();
vi.stubGlobal("fetch", fetchMock);

import { sendAuthEmail } from "@/server/auth-mail";

it("includes password-reset validity in the email body", async () => {
  process.env.RESEND_API_KEY = "test-key";
  process.env.AUTH_EMAIL_FROM = "NMT <test@example.com>";
  process.env.AUTH_BASE_URL = "http://localhost:3000";
  fetchMock.mockResolvedValue(new Response(null, { status: 200 }));
  await sendAuthEmail("user@example.com", "Відновлення пароля", "/reset-password?token=abc", { validityMinutes: 15 });
  const payload = JSON.parse(String(fetchMock.mock.calls.at(-1)?.[1]?.body));
  expect(payload.text).toContain("Посилання дійсне 15 хвилин.");
});
